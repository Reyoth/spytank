#ifndef I2C_COMM_H
#define I2C_COMM_H

#include <Arduino.h>

#define GOPIGO_ADDR 0x08    //GoPiGo Address 0x08
//Command list received from the Raspberry Pi
#define CMD_LED1_ON         201     //Turn On/Off the LED's
#define CMD_LED1_OFF        202     //Turn On/Off the LED's
#define CMD_LED2_ON         203     //Turn On/Off the LED's
#define CMD_LED2_OFF        204     //Turn On/Off the LED's
#define CMD_LED3_ON         205     //Turn On/Off the LED's
#define CMD_LED3_OFF        206     //Turn On/Off the LED's
#define CMD_LED4_ON         207     //Turn On/Off the LED's
#define CMD_LED4_OFF        208     //Turn On/Off the LED's
#define CMD_FORWARD	    105
#define CMD_BACKWARD	    107
#define CMD_LEFT	    98
#define CMD_RIGHT	    110

class I2C_comm {
private:
  uint8_t _cmd;
  int8_t _param1, _param2, _param3;

public:
  /** Crée un objet bacarComm */
  I2C_comm ();

  /** Initialise la communication avec l'Orange Pi.
   *  Cette fonction doit être appelée dans le setup du croquis. */
  void begin(void);

  /** Vérifie si un nouveau message de l'Orange Pi a été reçu.
   *  Si oui, le message est lu et les quatres paramètres du message (x,y,u,v) sont sauvés
   *  dans des champs privés de l'objet.
   *  Retour :
   *    true si un nouveau message a été reçu, false sinon. */
  bool newMessage(void);

  /** Renvoie la valeur du paramètre x du dernier message reçu */
  uint8_t readCmd(void);

  /** Renvoie la valeur du paramètre y du dernier message reçu */
  int8_t readParam1(void);
    
  /** Renvoie la valeur du paramètre u du dernier message reçu */
  int8_t readParam2(void);

  /** Renvoie la valeur du paramètre v du dernier message reçu */
  int8_t readParam3(void);

  /** Envoie un message à l'Orange Pi.
   *  Paramètres :
   *    x,y,u,v : paramètres à envoyer dans le message. */
//  void sendMessage(int32_t x, int32_t y, float u, float v);
};

#endif /* end of include guard #ifndef I2C_COMM_H */
