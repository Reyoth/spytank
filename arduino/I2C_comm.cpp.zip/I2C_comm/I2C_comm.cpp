#include <Wire.h>
#include "I2C_comm.h"

//********************************************************
// Low level functions prototypes
//********************************************************
volatile int cmd[5];
void sendData();
void receiveData(int byteCount);


//********************************************************
// Class implementation
//********************************************************
I2C_comm::I2C_comm(void) {
}

void I2C_comm::begin(void) {
  Wire.begin(GOPIGO_ADDR);                //Set up I2C
  Wire.onReceive(receiveData);
  Wire.onRequest(sendData);
  _cmd = 0;
  _param1 = 0;
  _param2 = 0;
  _param3 = 0;
  cmd[0] = 0;
}

uint8_t I2C_comm::readCmd(void) {
  return(_cmd);
}

int8_t I2C_comm::readParam1(void) {
  return(_param1);
}

int8_t I2C_comm::readParam2(void) {
  return(_param2);
}

int8_t I2C_comm::readParam3(void) {
  return(_param3);
}

bool I2C_comm::newMessage(void) {
  if (cmd[0] != 0) {
    _cmd = cmd[0];
    _param1 = cmd[1];
    _param2 = cmd[2];
    _param3 = cmd[3];
    cmd[0] = 0;
    return (true);
  } else {
    return(false);
  }
}
/*
void I2C_comm::sendMessage(int32_t x, int32_t y, float u, float v) {
  const char* HEAD="EHLO";
  int HEADLENGTH = 4;
  Serial.write((byte*)(HEAD), HEADLENGTH);
  Serial.write((byte*)&x, sizeof(int32_t));
  Serial.write((byte*)&y, sizeof(int32_t));
  Serial.write((byte*)&u, sizeof(float));
  Serial.write((byte*)&v, sizeof(float));
  Serial.flush();
}
*/

//Receive commands via I2C
void receiveData(int byteCount) {  
   static int index = 0;
   
    while(Wire.available()) {
        //When the buffer gets filled up with 4 bytes( the commands have to be 4 bytes in size), set the index back to 0 to read the next command
        if(Wire.available()==4) {
            index=0;
        }
        cmd[index++] = Wire.read(); //Load the command into the buffer
     }
 }


// callback for sending data
volatile int ind=0;
void sendData() {
}

